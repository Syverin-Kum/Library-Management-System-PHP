<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "qrcodedb";

// Create a connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Die if connection was not successful
?>